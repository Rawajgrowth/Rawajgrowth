import { useState, useEffect, useRef, useCallback } from 'react'

// ─── Data ────────────────────────────────────────────────────────────────────

const PRODUCTS = [
  { id: 1, name: 'سماعات سوني WH-1000XM5 لاسلكية', price: 'ر.س 1,299', rawPrice: 1299, oldPrice: 'ر.س 1,599', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop&auto=format', isNew: true, promo: 'خصم 19%', rating: 4.5, reviews: 128, saleable: true, sku: 'SNY-XM5-BLK' },
  { id: 2, name: 'ساعة أبل ووتش Series 9 - 45mm', price: 'ر.س 1,799', rawPrice: 1799, oldPrice: '', image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 5, reviews: 64, saleable: true, sku: 'APL-W9-45' },
  { id: 3, name: 'لابتوب ماك بوك برو M3 Pro - 14 بوصة', price: 'ر.س 7,299', rawPrice: 7299, oldPrice: 'ر.س 8,199', image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop&auto=format', isNew: true, promo: 'عرض محدود', rating: 4.8, reviews: 42, saleable: true, sku: 'APL-MBP-M3' },
  { id: 4, name: 'آيباد برو 12.9 بوصة M2', price: 'ر.س 3,499', rawPrice: 3499, oldPrice: '', image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.7, reviews: 89, saleable: true, sku: 'APL-IPD-M2' },
  { id: 5, name: 'كاميرا سوني Alpha A7 IV', price: 'ر.س 9,999', rawPrice: 9999, oldPrice: 'ر.س 11,499', image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop&auto=format', isNew: false, promo: 'وفّر 13%', rating: 4.9, reviews: 31, saleable: true, sku: 'SNY-A7IV' },
  { id: 6, name: 'مكبر صوت JBL Charge 5 مقاوم للماء', price: 'ر.س 599', rawPrice: 599, oldPrice: 'ر.س 749', image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop&auto=format', isNew: true, promo: 'الأكثر مبيعاً', rating: 4.6, reviews: 215, saleable: true, sku: 'JBL-CHG5' },
  { id: 7, name: 'شاشة سامسونج Odyssey 4K 32 بوصة', price: 'ر.س 2,199', rawPrice: 2199, oldPrice: '', image: 'https://images.unsplash.com/photo-1527443224154-c4a573d5f5a8?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.4, reviews: 57, saleable: false, sku: 'SAM-ODY-32' },
  { id: 8, name: 'لوحة مفاتيح Keychron K2 ميكانيكية', price: 'ر.س 449', rawPrice: 449, oldPrice: 'ر.س 529', image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.3, reviews: 93, saleable: true, sku: 'KCH-K2-WH' },
]

const CATEGORIES = [
  { name: 'الإلكترونيات', icon: '💻' },
  { name: 'الملابس', icon: '👕' },
  { name: 'الأجهزة المنزلية', icon: '🏠' },
  { name: 'الرياضة', icon: '⚽' },
  { name: 'الجمال', icon: '💄' },
  { name: 'الكتب', icon: '📚' },
  { name: 'الألعاب', icon: '🎮' },
  { name: 'السيارات', icon: '🚗' },
]

const BRANDS = [
  { name: 'Apple', img: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=120&h=80&fit=crop&auto=format' },
  { name: 'Samsung', img: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=120&h=80&fit=crop&auto=format' },
  { name: 'Sony', img: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=120&h=80&fit=crop&auto=format' },
  { name: 'JBL', img: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=120&h=80&fit=crop&auto=format' },
  { name: 'LG', img: 'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=120&h=80&fit=crop&auto=format' },
]

const BANNERS = [
  { id: 1, title: 'أحدث الإلكترونيات بأفضل الأسعار', sub: 'خصومات تصل إلى 30% على المنتجات المختارة', cta: 'تسوق الآن', img: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=1200&h=500&fit=crop&auto=format' },
  { id: 2, title: 'عروض نهاية الموسم الحصرية', sub: 'لفترة محدودة — لا تفوّت الفرصة', cta: 'اكتشف العروض', img: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=500&fit=crop&auto=format' },
  { id: 3, title: 'أجهزة آبل الأصلية', sub: 'الضمان الرسمي — شحن مجاني لجميع أنحاء المملكة', cta: 'تسوق آبل', img: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=1200&h=500&fit=crop&auto=format' },
]

const FEATURES = [
  { icon: '🚚', title: 'شحن مجاني', sub: 'على الطلبات فوق 200 ر.س' },
  { icon: '↩️', title: 'إرجاع سهل', sub: 'خلال 30 يوماً بدون أسئلة' },
  { icon: '🔒', title: 'دفع آمن', sub: 'تشفير SSL 256-bit' },
  { icon: '🎧', title: 'دعم 24/7', sub: 'فريق خدمة العملاء متاح دائماً' },
]

const REVIEWS = [
  { name: 'محمد الشهري', rating: 5, text: 'تجربة تسوق رائعة، وصل الطلب في الوقت المحدد وبحالة ممتازة. أنصح الجميع بالتسوق من هنا.', date: 'منذ 3 أيام', avatar: 'م' },
  { name: 'سارة العتيبي', rating: 4, text: 'جودة المنتج تفوق التوقعات والتغليف احترافي جداً. سرعة التوصيل كانت مفاجأة سارة.', date: 'منذ أسبوع', avatar: 'س' },
  { name: 'فهد الدوسري', rating: 5, text: 'أسعار تنافسية جداً مقارنة بالمتاجر الأخرى. المنتج أصلي 100% مع كرت الضمان.', date: 'منذ أسبوعين', avatar: 'ف' },
]

const NOTIFICATIONS = [
  { icon: '📦', text: 'طلبك رقم #10421 في طريقه إليك', sub: 'تم شحن طلبك - التوصيل خلال يومين', time: 'منذ ساعة', unread: true },
  { icon: '✅', text: 'تم تأكيد طلبك رقم #10420', sub: 'تمت معالجة الدفع بنجاح', time: 'أمس', unread: false },
  { icon: '💰', text: 'لديك 150 نقطة جديدة في محفظة النقاط', sub: 'مكافأة على آخر عملية شراء', time: 'منذ 3 أيام', unread: false },
]

type Product = typeof PRODUCTS[0]
type Page = 'home' | 'product' | 'cart' | 'account' | 'category'

// Extended product pool for infinite scroll simulation
const ALL_PRODUCTS_POOL: Product[] = [
  ...PRODUCTS,
  { id: 9,  name: 'ماوس لوجيتك MX Master 3S اللاسلكي', price: 'ر.س 429', rawPrice: 429, oldPrice: 'ر.س 529', image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=400&fit=crop&auto=format', isNew: true, promo: 'جديد', rating: 4.7, reviews: 74, saleable: true, sku: 'LGT-MXM3S' },
  { id: 10, name: 'سماعة AirPods Pro الجيل الثاني', price: 'ر.س 999', rawPrice: 999, oldPrice: '', image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.8, reviews: 310, saleable: true, sku: 'APL-APP2' },
  { id: 11, name: 'تابلت سامسونج Galaxy Tab S9 Ultra', price: 'ر.س 4,299', rawPrice: 4299, oldPrice: 'ر.س 4,999', image: 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&h=400&fit=crop&auto=format', isNew: false, promo: 'وفّر 700 ر.س', rating: 4.6, reviews: 55, saleable: true, sku: 'SAM-TS9U' },
  { id: 12, name: 'طابعة HP LaserJet Pro M404dn', price: 'ر.س 1,149', rawPrice: 1149, oldPrice: '', image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.2, reviews: 38, saleable: true, sku: 'HP-LJM404' },
  { id: 13, name: 'راوتر ASUS ROG Rapture WiFi 6E', price: 'ر.س 1,699', rawPrice: 1699, oldPrice: 'ر.س 1,899', image: 'https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=400&h=400&fit=crop&auto=format', isNew: true, promo: 'WiFi 6E', rating: 4.5, reviews: 29, saleable: true, sku: 'ASUS-ROGRTR' },
  { id: 14, name: 'هاتف Samsung Galaxy S24 Ultra 256GB', price: 'ر.س 4,799', rawPrice: 4799, oldPrice: 'ر.س 5,299', image: 'https://images.unsplash.com/photo-1610945264803-c22b62d2a7b3?w=400&h=400&fit=crop&auto=format', isNew: false, promo: 'الأكثر مبيعاً', rating: 4.9, reviews: 421, saleable: true, sku: 'SAM-S24U' },
  { id: 15, name: 'هارد SSD Samsung 990 Pro 2TB NVMe', price: 'ر.س 649', rawPrice: 649, oldPrice: 'ر.س 799', image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.8, reviews: 187, saleable: true, sku: 'SAM-990P2T' },
  { id: 16, name: 'شاشة Dell UltraSharp U2723D 4K 27"', price: 'ر.س 2,799', rawPrice: 2799, oldPrice: '', image: 'https://images.unsplash.com/photo-1527443224154-c4a573d5f5a8?w=400&h=400&fit=crop&auto=format', isNew: false, promo: '', rating: 4.7, reviews: 62, saleable: false, sku: 'DEL-U2723D' },
]

const PAGE_SIZE = 8

// ─── Helpers ─────────────────────────────────────────────────────────────────

function Stars({ rating, size = 'sm' }: { rating: number; size?: 'sm' | 'md' | 'lg' }) {
  const sz = size === 'lg' ? 'text-xl' : size === 'md' ? 'text-base' : 'text-sm'
  return (
    <span className={`${sz} leading-none`} style={{ direction: 'ltr', display: 'inline-flex', gap: 1 }}>
      {[1,2,3,4,5].map(i => (
        <span key={i} style={{ color: i <= Math.round(rating) ? '#f59e0b' : '#d1d5db' }}>★</span>
      ))}
    </span>
  )
}

function Badge({ children, color = 'brand' }: { children: React.ReactNode; color?: 'brand' | 'accent' | 'green' | 'warning' }) {
  const colors = {
    brand: { background: 'var(--brand)', color: '#fff' },
    accent: { background: 'var(--accent)', color: '#fff' },
    green: { background: '#16a34a', color: '#fff' },
    warning: { background: '#f59e0b', color: '#fff' },
  }
  return (
    <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={colors[color]}>
      {children}
    </span>
  )
}

// ─── Product Card ─────────────────────────────────────────────────────────────

function ProductCard({ product, onSelect, onAddCart }: { product: Product; onSelect: () => void; onAddCart: (p: Product) => void }) {
  const [wished, setWished] = useState(false)
  const [added, setAdded] = useState(false)

  return (
    <div className="product-card-hover group relative bg-white rounded-2xl overflow-hidden cursor-pointer"
      style={{ border: '1px solid var(--border)' }}
      onClick={onSelect}>
      {product.isNew && (
        <div className="absolute top-3 right-3 z-10"><Badge>جديد</Badge></div>
      )}
      {product.promo && (
        <div className="absolute top-3 left-3 z-10"><Badge color="accent">{product.promo}</Badge></div>
      )}
      <div className="relative overflow-hidden" style={{ background: '#f0f4ff', height: 196 }}>
        <img src={product.image} alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        {!product.saleable && (
          <div className="absolute inset-0 flex items-center justify-center"
            style={{ background: 'rgba(0,0,0,0.45)' }}>
            <span className="text-white font-bold text-sm px-3 py-1 rounded-full bg-gray-700">نفذ المخزون</span>
          </div>
        )}
        <div className="absolute inset-0 flex items-end justify-between p-3 opacity-0 group-hover:opacity-100 transition-all duration-200">
          <button onClick={e => { e.stopPropagation(); setWished(!wished) }}
            className="w-9 h-9 rounded-full bg-white flex items-center justify-center shadow-md hover:scale-110 transition-transform"
            title="أضف للمفضلة">
            <span style={{ color: wished ? '#e8412a' : '#9ca3af', fontSize: 17 }}>{wished ? '♥' : '♡'}</span>
          </button>
          {product.saleable && (
            <button onClick={e => { e.stopPropagation(); setAdded(true); onAddCart(product); setTimeout(() => setAdded(false), 1500) }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold shadow-md transition-all"
              style={{ background: added ? '#16a34a' : 'var(--brand)', color: '#fff' }}>
              <span>{added ? '✓ تمت الإضافة' : '+ أضف للسلة'}</span>
            </button>
          )}
        </div>
      </div>
      <div className="p-4">
        <p className="text-sm font-semibold leading-snug mb-2 line-clamp-2" style={{ color: 'var(--foreground)', minHeight: 40 }}>{product.name}</p>
        <div className="flex items-center gap-1 mb-3">
          <Stars rating={product.rating} />
          <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>({product.reviews})</span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-black text-base" style={{ color: 'var(--brand)' }}>{product.price}</span>
            {product.oldPrice && (
              <span className="text-xs line-through" style={{ color: 'var(--muted-foreground)' }}>{product.oldPrice}</span>
            )}
          </div>
          {!product.saleable && <span className="text-xs" style={{ color: 'var(--accent)' }}>نفذ</span>}
        </div>
      </div>
    </div>
  )
}

// ─── Header ───────────────────────────────────────────────────────────────────

// Mobile category drawer
function CategoryDrawer({ open, onClose, onSelect }: {
  open: boolean
  onClose: () => void
  onSelect: (cat: typeof CATEGORIES[0]) => void
}) {
  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 z-50 transition-opacity duration-300 md:hidden"
        style={{
          background: 'rgba(0,0,0,0.45)',
          pointerEvents: open ? 'auto' : 'none',
          opacity: open ? 1 : 0,
        }}
      />
      {/* Drawer panel — slides in from right (RTL) */}
      <div
        className="fixed top-0 right-0 h-full z-50 flex flex-col md:hidden"
        style={{
          width: 280,
          background: '#fff',
          boxShadow: '-4px 0 24px rgba(0,0,0,0.15)',
          transform: open ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.28s cubic-bezier(.4,0,.2,1)',
          direction: 'rtl',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4"
          style={{ borderBottom: '1px solid var(--border)', background: 'var(--brand)' }}>
          <span className="font-black text-white text-base">تصفح الفئات</span>
          <button onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-lg hover:bg-white/20 transition-colors">
            ✕
          </button>
        </div>
        {/* Category list */}
        <ul className="flex-1 overflow-y-auto py-2">
          {CATEGORIES.map((cat, i) => (
            <li key={cat.name}>
              <button
                onClick={() => { onSelect(cat); onClose() }}
                className="w-full flex items-center gap-4 px-5 py-4 text-right hover:bg-blue-50 active:bg-blue-100 transition-colors"
                style={{
                  borderBottom: i < CATEGORIES.length - 1 ? '1px solid var(--border)' : 'none',
                }}
              >
                <span className="text-2xl w-8 text-center flex-shrink-0">{cat.icon}</span>
                <span className="font-semibold text-sm flex-1">{cat.name}</span>
                <span className="text-lg" style={{ color: 'var(--muted-foreground)' }}>‹</span>
              </button>
            </li>
          ))}
        </ul>
        {/* Footer hint */}
        <div className="px-5 py-4 text-center" style={{ borderTop: '1px solid var(--border)' }}>
          <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>اضغط على فئة للدخول إليها</p>
        </div>
      </div>
    </>
  )
}

function Header({ cartCount, onCartClick, onPageChange, onCategorySelect, activePage }: {
  cartCount: number
  onCartClick: () => void
  onPageChange: (p: Page) => void
  onCategorySelect: (cat: typeof CATEGORIES[0]) => void
  activePage: Page
}) {
  const [notifOpen, setNotifOpen] = useState(false)
  const [acctOpen, setAcctOpen] = useState(false)
  const [catDrawerOpen, setCatDrawerOpen] = useState(false)
  const [searchVal, setSearchVal] = useState('')

  return (
    <>
      <CategoryDrawer
        open={catDrawerOpen}
        onClose={() => setCatDrawerOpen(false)}
        onSelect={onCategorySelect}
      />

      <header className="sticky top-0 z-40" style={{ background: '#fff', boxShadow: '0 1px 0 var(--border)' }}>
        {/* Announcement bar */}
        <div className="text-center text-xs py-1.5 text-white font-medium tracking-wide"
          style={{ background: 'var(--brand-dark, #2d5cd6)' }}>
          🎉 &nbsp; شحن مجاني على جميع الطلبات فوق 200 ر.س — عرض لفترة محدودة فقط
        </div>

        {/* Main header */}
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          {/* Mobile: hamburger categories button */}
          <button
            onClick={() => setCatDrawerOpen(true)}
            className="md:hidden flex flex-col items-center justify-center w-9 h-9 rounded-xl gap-1 hover:bg-gray-100 transition-colors flex-shrink-0"
            aria-label="الفئات"
          >
            <span className="block w-5 h-0.5 rounded-full" style={{ background: 'var(--foreground)' }} />
            <span className="block w-5 h-0.5 rounded-full" style={{ background: 'var(--foreground)' }} />
            <span className="block w-3 h-0.5 rounded-full self-start" style={{ background: 'var(--foreground)' }} />
          </button>

          {/* Logo */}
          <button onClick={() => onPageChange('home')} className="flex items-center gap-2 flex-shrink-0">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-lg font-black"
              style={{ background: 'var(--brand)' }}>ت</div>
            <span className="text-xl font-black tracking-tight hidden sm:inline" style={{ color: 'var(--foreground)' }}>twsaa</span>
          </button>

          {/* Search */}
          <div className="flex-1 max-w-2xl">
            <div className="flex items-center rounded-xl overflow-hidden"
              style={{ background: 'var(--background)', border: '1.5px solid var(--border)' }}>
              <input type="text" value={searchVal} onChange={e => setSearchVal(e.target.value)}
                placeholder="ابحث عن منتج، ماركة، أو فئة..."
                className="flex-1 px-4 py-2.5 text-sm outline-none bg-transparent"
                style={{ direction: 'rtl', color: 'var(--foreground)' }} />
              <button className="px-4 py-2.5 text-sm font-bold text-white transition-colors"
                style={{ background: 'var(--brand)', minWidth: 48 }}>🔍</button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 flex-shrink-0">
            {/* Cart */}
            <button onClick={onCartClick}
              className="relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium hover:bg-gray-50 transition-colors">
              <span className="text-lg">🛒</span>
              <span className="hidden md:inline text-sm" style={{ color: 'var(--foreground)' }}>السلة</span>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full text-xs font-bold flex items-center justify-center text-white"
                  style={{ background: 'var(--accent)' }}>{cartCount}</span>
              )}
            </button>

            {/* Wallet */}
            <button className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium hover:bg-gray-50 transition-colors">
              <span className="text-lg">💰</span>
              <span style={{ color: 'var(--brand)', fontWeight: 700 }}>250 ر.س</span>
            </button>

            {/* Notifications */}
            <div className="relative">
              <button onClick={() => { setNotifOpen(!notifOpen); setAcctOpen(false) }}
                className="relative flex items-center gap-1 px-3 py-2 rounded-xl text-sm hover:bg-gray-50 transition-colors">
                <span className="text-lg">🔔</span>
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: 'var(--accent)' }} />
              </button>
              {notifOpen && (
                <div className="absolute top-full mt-2 w-80 bg-white rounded-2xl shadow-2xl z-50 overflow-hidden"
                  style={{ border: '1px solid var(--border)', right: 0 }}>
                  <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: '1px solid var(--border)' }}>
                    <span className="font-bold text-sm">الإشعارات</span>
                    <span className="text-xs" style={{ color: 'var(--brand)' }}>تحديد الكل مقروءاً</span>
                  </div>
                  {NOTIFICATIONS.map((n, i) => (
                    <div key={i} className="flex items-start gap-3 px-4 py-3 hover:bg-gray-50 cursor-pointer transition-colors"
                      style={{ background: n.unread ? 'var(--brand-light, #eef2ff)' : '#fff', borderBottom: '1px solid var(--border)' }}>
                      <span className="text-xl mt-0.5">{n.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold leading-snug">{n.text}</p>
                        <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{n.sub}</p>
                        <p className="text-xs mt-1" style={{ color: 'var(--brand)' }}>{n.time}</p>
                      </div>
                      {n.unread && <div className="w-2 h-2 rounded-full mt-2 flex-shrink-0" style={{ background: 'var(--brand)' }} />}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Account */}
            <div className="relative">
              <button onClick={() => { setAcctOpen(!acctOpen); setNotifOpen(false) }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm hover:bg-gray-50 transition-colors">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold"
                  style={{ background: 'var(--brand)' }}>م</div>
                <span className="hidden md:inline text-sm font-medium" style={{ color: 'var(--foreground)' }}>محمد</span>
              </button>
              {acctOpen && (
                <div className="absolute top-full mt-2 w-52 bg-white rounded-2xl shadow-2xl z-50 overflow-hidden py-2"
                  style={{ border: '1px solid var(--border)', right: 0 }}>
                  {[
                    ['👤', 'الملف الشخصي'],
                    ['📦', 'طلباتي'],
                    ['♡', 'المفضلة'],
                    ['💰', 'المحفظة'],
                    ['🔔', 'الإشعارات'],
                    ['📍', 'عناويني'],
                  ].map(([icon, label]) => (
                    <button key={label} onClick={() => { onPageChange('account'); setAcctOpen(false) }}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors">
                      <span>{icon}</span>
                      <span>{label}</span>
                    </button>
                  ))}
                  <div style={{ borderTop: '1px solid var(--border)', margin: '4px 0' }} />
                  <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                    style={{ color: 'var(--accent)' }}>
                    <span>🚪</span><span>تسجيل الخروج</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Category nav — desktop/tablet only */}
        <nav className="hidden md:block" style={{ borderTop: '1px solid var(--border)' }}>
          <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 overflow-x-auto py-1.5" style={{ scrollbarWidth: 'none' }}>
            <span className="text-xs font-bold px-3 py-1 rounded-lg whitespace-nowrap"
              style={{ color: 'var(--muted-foreground)' }}>الفئات:</span>
            {CATEGORIES.map(cat => (
              <button key={cat.name}
                onClick={() => onCategorySelect(cat)}
                className="whitespace-nowrap flex items-center gap-1.5 px-4 py-1.5 text-sm rounded-lg hover:bg-blue-50 transition-colors font-medium"
                style={{ color: 'var(--foreground)' }}>
                <span>{cat.icon}</span>{cat.name}
              </button>
            ))}
          </div>
        </nav>
      </header>
    </>
  )
}

// ─── Hero Banner ──────────────────────────────────────────────────────────────

function HeroBanner() {
  const [active, setActive] = useState(0)
  const b = BANNERS[active]

  return (
    <div className="relative overflow-hidden rounded-2xl" style={{ height: 360 }}>
      <img src={b.img} alt={b.title} className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500" />
      <div className="absolute inset-0" style={{ background: 'linear-gradient(to left, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 60%, transparent 100%)' }} />
      <div className="absolute inset-0 flex flex-col justify-center px-12" style={{ direction: 'rtl' }}>
        <p className="text-sm font-semibold mb-2" style={{ color: 'var(--brand)' }}>⚡ عرض حصري</p>
        <h1 className="text-3xl font-black text-white mb-3 leading-tight max-w-md">{b.title}</h1>
        <p className="text-base text-gray-200 mb-7">{b.sub}</p>
        <button className="self-start px-7 py-3 rounded-xl font-bold text-sm transition-all hover:opacity-90 active:scale-95 text-white"
          style={{ background: 'var(--brand)' }}>
          {b.cta} →
        </button>
      </div>
      {/* Dots */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
        {BANNERS.map((_, i) => (
          <button key={i} onClick={() => setActive(i)}
            className="h-2 rounded-full transition-all duration-300"
            style={{ background: i === active ? '#fff' : 'rgba(255,255,255,0.4)', width: i === active ? 28 : 8 }} />
        ))}
      </div>
    </div>
  )
}

// ─── Cart Drawer ──────────────────────────────────────────────────────────────

function CartDrawer({ items, onClose, onRemove }: { items: Product[]; onClose: () => void; onRemove: (id: number) => void }) {
  const total = items.reduce((s, p) => s + p.rawPrice, 0)
  const shipping = total >= 200 ? 0 : 25

  return (
    <div className="fixed inset-0 z-50 flex" style={{ direction: 'rtl' }}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-white h-full flex flex-col shadow-2xl ms-auto"
        style={{ borderRight: '1px solid var(--border)' }}>
        <div className="flex items-center justify-between p-5" style={{ borderBottom: '1px solid var(--border)' }}>
          <h2 className="font-black text-lg">سلة التسوق</h2>
          <div className="flex items-center gap-3">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{items.length} منتج</span>
            <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center text-lg hover:bg-gray-100 transition-colors">✕</button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {items.length === 0 ? (
            <div className="text-center py-20 space-y-3">
              <div className="text-6xl">🛒</div>
              <p className="font-semibold" style={{ color: 'var(--muted-foreground)' }}>سلتك فارغة</p>
              <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>أضف منتجات لتبدأ التسوق</p>
            </div>
          ) : items.map((item, i) => (
            <div key={`${item.id}-${i}`} className="flex gap-3 items-center p-3 rounded-xl"
              style={{ border: '1px solid var(--border)' }}>
              <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover flex-shrink-0" style={{ background: '#f0f4ff' }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold leading-snug line-clamp-2">{item.name}</p>
                <p className="text-sm font-black mt-1" style={{ color: 'var(--brand)' }}>{item.price}</p>
              </div>
              <button onClick={() => onRemove(i)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs flex-shrink-0 hover:bg-red-50 transition-colors"
                style={{ color: 'var(--accent)', border: '1px solid var(--accent)' }}>✕</button>
            </div>
          ))}
        </div>

        {items.length > 0 && (
          <div className="p-5 space-y-4" style={{ borderTop: '1px solid var(--border)' }}>
            {/* Coupon */}
            <div className="flex gap-2">
              <input type="text" placeholder="كود الخصم" className="flex-1 px-3 py-2 rounded-lg text-sm outline-none"
                style={{ border: '1.5px solid var(--border)', background: 'var(--background)' }} />
              <button className="px-4 py-2 rounded-lg text-sm font-bold text-white"
                style={{ background: 'var(--foreground)' }}>تطبيق</button>
            </div>
            {/* Totals */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--muted-foreground)' }}>المجموع الفرعي</span>
                <span className="font-semibold">ر.س {total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--muted-foreground)' }}>الشحن</span>
                {shipping === 0
                  ? <span className="font-semibold text-green-600">مجاني 🎉</span>
                  : <span className="font-semibold">ر.س {shipping}</span>}
              </div>
              <div className="flex justify-between font-black text-base pt-2" style={{ borderTop: '1px solid var(--border)' }}>
                <span>الإجمالي</span>
                <span style={{ color: 'var(--brand)', fontSize: '1.1rem' }}>ر.س {(total + shipping).toLocaleString()}</span>
              </div>
            </div>
            <button className="w-full py-3.5 rounded-xl font-black text-white transition-all hover:opacity-90 active:scale-95 text-sm"
              style={{ background: 'var(--brand)' }}>
              إتمام الشراء →
            </button>
            <button onClick={onClose} className="w-full py-2.5 rounded-xl font-semibold text-sm hover:bg-gray-50 transition-colors"
              style={{ color: 'var(--brand)', border: '1.5px solid var(--border)' }}>
              متابعة التسوق
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Product Detail ───────────────────────────────────────────────────────────

function ProductDetail({ product, onBack, onAddCart }: { product: Product; onBack: () => void; onAddCart: (p: Product) => void }) {
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState<'desc' | 'reviews' | 'related'>('desc')
  const [wished, setWished] = useState(false)
  const [addedMsg, setAddedMsg] = useState(false)

  const handleAdd = () => {
    for (let i = 0; i < qty; i++) onAddCart(product)
    setAddedMsg(true)
    setTimeout(() => setAddedMsg(false), 2000)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8" style={{ direction: 'rtl' }}>
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm mb-6" style={{ color: 'var(--muted-foreground)' }}>
        <button onClick={onBack} className="hover:text-brand transition-colors" style={{ color: 'var(--brand)' }}>الرئيسية</button>
        <span>/</span>
        <span>الإلكترونيات</span>
        <span>/</span>
        <span style={{ color: 'var(--foreground)' }} className="line-clamp-1">{product.name}</span>
      </div>

      <div className="grid md:grid-cols-2 gap-10 mb-12">
        {/* Gallery */}
        <div className="space-y-3">
          <div className="rounded-2xl overflow-hidden" style={{ background: '#f0f4ff', height: 400 }}>
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex gap-3">
            {[product.image, product.image, product.image].map((img, i) => (
              <div key={i} className="w-20 h-20 rounded-xl overflow-hidden cursor-pointer"
                style={{ border: i === 0 ? '2.5px solid var(--brand)' : '1.5px solid var(--border)', background: '#f0f4ff' }}>
                <img src={img} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="space-y-5">
          <div>
            <div className="flex items-center gap-2 mb-2">
              {product.isNew && <Badge>جديد</Badge>}
              {product.promo && <Badge color="accent">{product.promo}</Badge>}
              <Badge color={product.saleable ? 'green' : 'accent'}>{product.saleable ? 'متوفر في المخزون' : 'نفذ المخزون'}</Badge>
            </div>
            <h1 className="text-2xl font-black leading-tight mb-3">{product.name}</h1>
            <div className="flex items-center gap-3">
              <Stars rating={product.rating} size="md" />
              <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{product.reviews} تقييم</span>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>SKU: {product.sku}</span>
            </div>
          </div>

          {/* Price */}
          <div className="p-4 rounded-2xl" style={{ background: 'var(--background)', border: '1.5px solid var(--border)' }}>
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-black" style={{ color: 'var(--brand)' }}>{product.price}</span>
              {product.oldPrice && (
                <span className="text-base line-through" style={{ color: 'var(--muted-foreground)' }}>{product.oldPrice}</span>
              )}
            </div>
            {product.oldPrice && (
              <p className="text-sm mt-1" style={{ color: '#16a34a' }}>
                ✓ توفر {(parseInt(product.oldPrice.replace(/\D/g,'')) - product.rawPrice).toLocaleString()} ر.س
              </p>
            )}
          </div>

          {/* Qty */}
          <div className="flex items-center gap-4">
            <span className="text-sm font-semibold">الكمية:</span>
            <div className="flex items-center gap-1 rounded-xl overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
              <button onClick={() => setQty(q => Math.max(1, q-1))}
                className="w-10 h-10 flex items-center justify-center text-lg font-bold hover:bg-gray-100 transition-colors">−</button>
              <span className="w-10 text-center font-bold text-sm">{qty}</span>
              <button onClick={() => setQty(q => q+1)}
                className="w-10 h-10 flex items-center justify-center text-lg font-bold hover:bg-gray-100 transition-colors">+</button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button onClick={handleAdd} disabled={!product.saleable}
              className="flex-1 py-3.5 rounded-xl font-black text-white text-sm transition-all hover:opacity-90 active:scale-95 disabled:opacity-40"
              style={{ background: addedMsg ? '#16a34a' : 'var(--brand)' }}>
              {addedMsg ? '✓ تمت الإضافة للسلة' : product.saleable ? '🛒 أضف إلى السلة' : 'نفذ المخزون'}
            </button>
            <button onClick={() => setWished(!wished)}
              className="w-12 h-12 rounded-xl flex items-center justify-center text-xl transition-all hover:scale-110"
              style={{ border: '1.5px solid var(--border)', color: wished ? '#e8412a' : 'var(--muted-foreground)' }}>
              {wished ? '♥' : '♡'}
            </button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-2 gap-2">
            {FEATURES.map(f => (
              <div key={f.title} className="flex items-center gap-2 p-3 rounded-xl text-xs"
                style={{ background: 'var(--background)', border: '1px solid var(--border)' }}>
                <span className="text-lg">{f.icon}</span>
                <div>
                  <p className="font-bold">{f.title}</p>
                  <p style={{ color: 'var(--muted-foreground)' }}>{f.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
        <div className="flex" style={{ borderBottom: '1px solid var(--border)' }}>
          {[['desc', 'الوصف'], ['reviews', 'التقييمات'], ['related', 'منتجات مشابهة']].map(([k, label]) => (
            <button key={k} onClick={() => setTab(k as any)}
              className="px-6 py-3.5 text-sm font-bold transition-all"
              style={{
                background: tab === k ? 'var(--brand)' : '#fff',
                color: tab === k ? '#fff' : 'var(--muted-foreground)',
                borderBottom: tab === k ? '2px solid var(--brand)' : '2px solid transparent',
              }}>{label}</button>
          ))}
        </div>
        <div className="p-6">
          {tab === 'desc' && (
            <div className="space-y-4 text-sm leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
              <p>منتج عالي الجودة مع ضمان الأصالة والجودة. يأتي في عبوة أصلية مع كافة الملحقات والكرت ضمان رسمي.</p>
              <ul className="space-y-2 list-none">
                {['ضمان لمدة سنة كاملة', 'شحن مجاني وسريع', 'إرجاع مجاني خلال 30 يوماً', 'منتج أصلي 100%'].map(f => (
                  <li key={f} className="flex items-center gap-2"><span style={{ color: 'var(--brand)' }}>✓</span> {f}</li>
                ))}
              </ul>
            </div>
          )}
          {tab === 'reviews' && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 rounded-xl" style={{ background: 'var(--background)' }}>
                <div className="text-center">
                  <div className="text-4xl font-black" style={{ color: 'var(--brand)' }}>{product.rating}</div>
                  <Stars rating={product.rating} size="sm" />
                  <p className="text-xs mt-1" style={{ color: 'var(--muted-foreground)' }}>{product.reviews} تقييم</p>
                </div>
                <div className="flex-1 space-y-1.5">
                  {[5,4,3,2,1].map(s => (
                    <div key={s} className="flex items-center gap-2">
                      <span className="text-xs w-4">{s}★</span>
                      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
                        <div className="h-full rounded-full" style={{ background: 'var(--brand)', width: `${s === 5 ? 70 : s === 4 ? 20 : 10}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {REVIEWS.map((r, i) => (
                <div key={i} className="p-4 rounded-xl" style={{ border: '1px solid var(--border)' }}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: 'var(--brand)' }}>{r.avatar}</div>
                    <div>
                      <p className="font-bold text-sm">{r.name}</p>
                      <div className="flex items-center gap-2"><Stars rating={r.rating} /><span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{r.date}</span></div>
                    </div>
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>{r.text}</p>
                </div>
              ))}
            </div>
          )}
          {tab === 'related' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {PRODUCTS.filter(p => p.id !== product.id).slice(0, 4).map(p => (
                <ProductCard key={p.id} product={p} onSelect={() => {}} onAddCart={onAddCart} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Account Page ─────────────────────────────────────────────────────────────

function AccountPage() {
  const [section, setSection] = useState<'profile' | 'orders' | 'wallet' | 'wishlist' | 'addresses'>('profile')

  const MENU = [
    { key: 'profile', icon: '👤', label: 'الملف الشخصي' },
    { key: 'orders', icon: '📦', label: 'طلباتي' },
    { key: 'wallet', icon: '💰', label: 'المحفظة' },
    { key: 'wishlist', icon: '♡', label: 'المفضلة' },
    { key: 'addresses', icon: '📍', label: 'العناوين' },
  ] as const

  return (
    <div className="max-w-7xl mx-auto px-4 py-8" style={{ direction: 'rtl' }}>
      <h1 className="text-2xl font-black mb-6 section-title">حسابي</h1>
      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-56 flex-shrink-0">
          <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--border)', background: '#fff' }}>
            <div className="p-5 text-center" style={{ borderBottom: '1px solid var(--border)' }}>
              <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center text-2xl font-black text-white"
                style={{ background: 'var(--brand)' }}>م</div>
              <p className="font-bold text-sm">محمد الشهري</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>mohammed@email.com</p>
              <div className="flex items-center justify-center gap-1 mt-2">
                <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: 'var(--brand-light,#eef2ff)', color: 'var(--brand)' }}>⭐ 1,250 نقطة</span>
              </div>
            </div>
            <ul className="py-2">
              {MENU.map(m => (
                <li key={m.key}>
                  <button onClick={() => setSection(m.key)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors"
                    style={{
                      background: section === m.key ? 'var(--brand-light,#eef2ff)' : 'transparent',
                      color: section === m.key ? 'var(--brand)' : 'var(--foreground)',
                      fontWeight: section === m.key ? 700 : 400,
                      borderRight: section === m.key ? '3px solid var(--brand)' : '3px solid transparent',
                    }}>
                    <span>{m.icon}</span>{m.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {section === 'profile' && (
            <div className="rounded-2xl p-6 bg-white" style={{ border: '1.5px solid var(--border)' }}>
              <h2 className="font-black text-lg mb-5 section-title">الملف الشخصي</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  ['الاسم الأول', 'محمد'],
                  ['الاسم الأخير', 'الشهري'],
                  ['الجنس', 'ذكر'],
                  ['تاريخ الميلاد', '1990-05-15'],
                  ['البريد الإلكتروني', 'mohammed@email.com'],
                  ['رقم الهاتف', '0512345678'],
                ].map(([label, val]) => (
                  <div key={label}>
                    <label className="text-xs font-semibold mb-1 block" style={{ color: 'var(--muted-foreground)' }}>{label}</label>
                    <div className="px-4 py-2.5 rounded-xl text-sm font-medium" style={{ background: 'var(--background)', border: '1.5px solid var(--border)' }}>{val}</div>
                  </div>
                ))}
              </div>
              <button className="mt-5 px-6 py-2.5 rounded-xl font-bold text-sm text-white transition-all hover:opacity-90"
                style={{ background: 'var(--brand)' }}>تعديل الملف الشخصي</button>
            </div>
          )}

          {section === 'orders' && (
            <div className="rounded-2xl bg-white overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
              <div className="px-6 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
                <h2 className="font-black text-lg section-title">طلباتي</h2>
              </div>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: 'var(--background)', borderBottom: '1px solid var(--border)' }}>
                    {['رقم الطلب', 'التاريخ', 'الإجمالي', 'الحالة', 'إجراء'].map(h => (
                      <th key={h} className="px-5 py-3 text-right font-bold" style={{ color: 'var(--muted-foreground)', fontSize: 12 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { id: '#10421', date: '2024-01-15', total: 'ر.س 1,799', status: 'processing', statusLabel: 'قيد المعالجة', color: '#16a34a' },
                    { id: '#10420', date: '2024-01-10', total: 'ر.س 3,499', status: 'completed', statusLabel: 'مكتمل', color: '#2563eb' },
                    { id: '#10419', date: '2024-01-05', total: 'ر.س 599', status: 'canceled', statusLabel: 'ملغي', color: '#e8412a' },
                  ].map(order => (
                    <tr key={order.id} style={{ borderBottom: '1px solid var(--border)' }} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-4 font-bold" style={{ color: 'var(--brand)' }}>{order.id}</td>
                      <td className="px-5 py-4" style={{ color: 'var(--muted-foreground)' }}>{order.date}</td>
                      <td className="px-5 py-4 font-semibold">{order.total}</td>
                      <td className="px-5 py-4">
                        <span className="px-2.5 py-1 rounded-full text-xs font-bold text-white" style={{ background: order.color }}>{order.statusLabel}</span>
                      </td>
                      <td className="px-5 py-4">
                        <button className="text-xs font-bold hover:underline" style={{ color: 'var(--brand)' }}>عرض</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {section === 'wallet' && (
            <div className="space-y-4">
              <div className="rounded-2xl p-6 text-white" style={{ background: 'linear-gradient(135deg, var(--brand) 0%, #2d5cd6 100%)' }}>
                <p className="text-sm text-blue-200 mb-1">رصيد المحفظة</p>
                <p className="text-4xl font-black mb-1">250.00 <span className="text-xl">ر.س</span></p>
                <p className="text-sm text-blue-200">⭐ 1,250 نقطة ولاء</p>
              </div>
              <div className="rounded-2xl bg-white overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
                <div className="px-5 py-3" style={{ borderBottom: '1px solid var(--border)' }}>
                  <h3 className="font-bold section-title">سجل المعاملات</h3>
                </div>
                {[
                  { type: 'credit', desc: 'مكافأة طلب #10420', amount: '+50 ر.س', date: '2024-01-10' },
                  { type: 'debit', desc: 'استخدام في طلب #10419', amount: '-25 ر.س', date: '2024-01-05' },
                  { type: 'credit', desc: 'مكافأة إحالة صديق', amount: '+100 ر.س', date: '2023-12-20' },
                ].map((t, i) => (
                  <div key={i} className="flex items-center justify-between px-5 py-4"
                    style={{ borderBottom: '1px solid var(--border)' }}>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center"
                        style={{ background: t.type === 'credit' ? '#dcfce7' : '#fee2e2' }}>
                        <span>{t.type === 'credit' ? '⬇️' : '⬆️'}</span>
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{t.desc}</p>
                        <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{t.date}</p>
                      </div>
                    </div>
                    <span className="font-black text-sm" style={{ color: t.type === 'credit' ? '#16a34a' : '#e8412a' }}>{t.amount}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'addresses' && (
            <div className="rounded-2xl bg-white p-6" style={{ border: '1.5px solid var(--border)' }}>
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-black text-lg section-title">عناويني</h2>
                <button className="px-4 py-2 rounded-xl text-sm font-bold text-white" style={{ background: 'var(--brand)' }}>+ إضافة عنوان</button>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { name: 'محمد الشهري', address: 'حي النزهة، شارع الملك فهد', city: 'الرياض', country: 'المملكة العربية السعودية', phone: '0512345678', default: true },
                  { name: 'محمد الشهري', address: 'حي العليا، برج المملكة', city: 'الرياض', country: 'المملكة العربية السعودية', phone: '0512345678', default: false },
                ].map((addr, i) => (
                  <div key={i} className="p-4 rounded-xl relative" style={{ border: `1.5px solid ${addr.default ? 'var(--brand)' : 'var(--border)'}`, background: addr.default ? 'var(--brand-light,#eef2ff)' : '#fff' }}>
                    {addr.default && <span className="absolute top-3 left-3 text-xs font-bold px-2 py-0.5 rounded-full text-white" style={{ background: 'var(--brand)' }}>افتراضي</span>}
                    <p className="font-bold text-sm">{addr.name}</p>
                    <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>{addr.address}</p>
                    <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{addr.city} — {addr.country}</p>
                    <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>📞 {addr.phone}</p>
                    <div className="flex gap-2 mt-3">
                      <button className="text-xs font-bold px-3 py-1.5 rounded-lg" style={{ background: 'var(--brand)', color: '#fff' }}>تعديل</button>
                      <button className="text-xs font-bold px-3 py-1.5 rounded-lg" style={{ border: '1px solid var(--accent)', color: 'var(--accent)' }}>حذف</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {section === 'wishlist' && (
            <div className="rounded-2xl bg-white p-6" style={{ border: '1.5px solid var(--border)' }}>
              <h2 className="font-black text-lg mb-5 section-title">المفضلة</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {PRODUCTS.slice(0, 4).map(p => (
                  <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ border: '1px solid var(--border)' }}>
                    <img src={p.image} alt={p.name} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" style={{ background: '#f0f4ff' }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold line-clamp-2 leading-snug">{p.name}</p>
                      <p className="font-black mt-1 text-sm" style={{ color: 'var(--brand)' }}>{p.price}</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      <button className="text-xs px-2 py-1 rounded-lg font-bold text-white" style={{ background: 'var(--brand)' }}>سلة</button>
                      <button className="text-xs px-2 py-1 rounded-lg font-bold" style={{ color: 'var(--accent)', border: '1px solid var(--accent)' }}>حذف</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Home Page ────────────────────────────────────────────────────────────────

function HomePage({ onProductSelect, onAddCart, onCategorySelect }: { onProductSelect: (p: Product) => void; onAddCart: (p: Product) => void; onCategorySelect: (cat: typeof CATEGORIES[0]) => void }) {
  const [tab, setTab] = useState<'all' | 'new' | 'sale'>('all')

  const filtered = {
    all: PRODUCTS,
    new: PRODUCTS.filter(p => p.isNew),
    sale: PRODUCTS.filter(p => !!p.oldPrice),
  }[tab]

  return (
    <main className="max-w-7xl mx-auto px-4 py-8 space-y-14">

      {/* Hero */}
      <HeroBanner />

      {/* Features */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {FEATURES.map(f => (
          <div key={f.title} className="bg-white rounded-2xl p-5 flex items-center gap-3"
            style={{ border: '1.5px solid var(--border)' }}>
            <span className="text-2xl">{f.icon}</span>
            <div>
              <p className="font-bold text-sm">{f.title}</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{f.sub}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Category grid */}
      <section>
        <div className="flex items-center gap-3 mb-5">
          <h2 className="text-xl font-black section-title">تسوق حسب الفئة</h2>
          <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
        </div>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
          {CATEGORIES.map(cat => (
            <button key={cat.name}
              onClick={() => onCategorySelect(cat)}
              className="flex flex-col items-center gap-2 py-4 px-2 rounded-2xl bg-white hover:shadow-md transition-all hover:-translate-y-0.5"
              style={{ border: '1.5px solid var(--border)' }}>
              <span className="text-2xl">{cat.icon}</span>
              <span className="text-xs font-semibold text-center leading-tight">{cat.name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Products section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-1 p-1 rounded-2xl" style={{ background: 'var(--muted)' }}>
            {[['all', 'الكل'], ['new', 'الجديدة'], ['sale', 'العروض']] .map(([k, label]) => (
              <button key={k} onClick={() => setTab(k as any)}
                className="px-5 py-2 rounded-xl text-sm font-bold transition-all"
                style={{
                  background: tab === k ? 'var(--brand)' : 'transparent',
                  color: tab === k ? '#fff' : 'var(--muted-foreground)',
                }}>
                {label}
              </button>
            ))}
          </div>
          <button className="text-sm font-bold hover:underline" style={{ color: 'var(--brand)' }}>عرض الكل →</button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {filtered.map(p => (
            <ProductCard key={p.id} product={p} onSelect={() => onProductSelect(p)} onAddCart={onAddCart} />
          ))}
        </div>
      </section>

      {/* Loyalty banner */}
      <div className="rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6"
        style={{ background: 'linear-gradient(135deg, var(--brand) 0%, #2d5cd6 100%)', color: '#fff' }}>
        <div>
          <p className="text-sm font-semibold text-blue-200 mb-2">⭐ برنامج الولاء</p>
          <h3 className="text-2xl font-black mb-2">لديك <span style={{ color: '#fbbf24' }}>1,250 نقطة</span></h3>
          <p className="text-sm text-blue-100">استبدل نقاطك بشحن مجاني، كوبونات خصم، أو منتجات مجانية</p>
        </div>
        <button className="whitespace-nowrap px-7 py-3.5 rounded-2xl font-black text-sm transition-all hover:opacity-90 flex-shrink-0"
          style={{ background: '#fbbf24', color: '#1a3a6b' }}>
          استبدل نقاطك الآن →
        </button>
      </div>

      {/* Brands */}
      <section>
        <div className="flex items-center gap-3 mb-5">
          <h2 className="text-xl font-black section-title">الماركات المميزة</h2>
          <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
        </div>
        <div className="flex gap-4 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
          {BRANDS.map(b => (
            <div key={b.name} className="flex-shrink-0 w-32 h-20 rounded-2xl overflow-hidden bg-white flex items-center justify-center cursor-pointer hover:shadow-md transition-all"
              style={{ border: '1.5px solid var(--border)' }}>
              <img src={b.img} alt={b.name} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section>
        <div className="flex items-center gap-3 mb-5">
          <h2 className="text-xl font-black section-title">آراء عملائنا</h2>
          <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
        </div>
        <div className="grid md:grid-cols-3 gap-5">
          {REVIEWS.map((r, i) => (
            <div key={i} className="bg-white rounded-2xl p-6 space-y-3 relative"
              style={{ border: '1.5px solid var(--border)' }}>
              <div className="text-4xl absolute top-4 left-4 opacity-10 font-black" style={{ color: 'var(--brand)' }}>"</div>
              <Stars rating={r.rating} size="md" />
              <p className="text-sm leading-relaxed" style={{ color: 'var(--foreground)' }}>"{r.text}"</p>
              <div className="flex items-center gap-3 pt-2" style={{ borderTop: '1px solid var(--border)' }}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-black text-sm"
                  style={{ background: 'var(--brand)' }}>{r.avatar}</div>
                <div>
                  <p className="text-sm font-bold">{r.name}</p>
                  <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{r.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer className="mt-16" style={{ background: '#111827', color: '#fff' }}>
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-10 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-lg font-black"
                style={{ background: 'var(--brand)' }}>ت</div>
              <span className="text-xl font-black">twsaa.com</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">
              منصة التسوق الإلكتروني الأولى في المملكة العربية السعودية
            </p>
            <div className="flex gap-2">
              {['📸', '🐦', '📘', '👻', '▶️'].map((icon, i) => (
                <button key={i} className="w-9 h-9 rounded-xl flex items-center justify-center text-sm transition-colors hover:opacity-80"
                  style={{ background: 'rgba(255,255,255,0.08)' }}>{icon}</button>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-sm text-gray-300">خدمة العملاء</h4>
            <ul className="space-y-2.5">
              {['اتصل بنا', 'الأسئلة الشائعة', 'سياسة الإرجاع', 'تتبع الطلب', 'دعم فني'].map(l => (
                <li key={l}><a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">{l}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-sm text-gray-300">روابط سريعة</h4>
            <ul className="space-y-2.5">
              {['من نحن', 'المدونة', 'الشروط والأحكام', 'سياسة الخصوصية', 'خريطة الموقع'].map(l => (
                <li key={l}><a href="#" className="text-sm text-gray-400 hover:text-white transition-colors">{l}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-sm text-gray-300">وسائل الدفع المقبولة</h4>
            <div className="flex flex-wrap gap-2 mb-5">
              {/* Visa */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center" style={{ background: '#1a1f71' }}>
                <svg viewBox="0 0 780 500" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="780" height="500" rx="40" fill="#1a1f71"/>
                  <path d="M292 331H240L272 170H324L292 331Z" fill="white"/>
                  <path d="M466 174c-10-4-27-8-47-8-52 0-89 27-89 66 0 29 26 45 46 55 20 10 27 17 27 26 0 14-16 20-31 20-21 0-32-3-50-10l-7-3-7 44c12 5 34 10 57 10 56 0 92-28 92-69 0-23-14-40-45-55-19-9-30-15-30-24 0-8 10-17 31-17 18 0 31 4 41 8l5 2 8-45z" fill="white"/>
                  <path d="M544 170h-40c-12 0-22 4-27 16l-79 145h56s9-25 11-30h68c2 7 6 30 6 30h49L544 170zm-66 99c4-12 21-55 21-55s4-12 7-19l3 17s9 44 11 57h-42z" fill="white"/>
                  <path d="M193 170l-51 110-6-28c-10-33-40-68-74-86l47 165h57l85-161h-58z" fill="white"/>
                  <path d="M100 170H16l-1 4c66 17 109 57 127 106l-18-90c-3-12-13-20-24-20z" fill="#FAA61A"/>
                </svg>
              </div>
              {/* Mastercard */}
              <div className="h-8 px-2 rounded-lg flex items-center justify-center" style={{ background: '#252525' }}>
                <svg viewBox="0 0 38 24" height="18" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="15" cy="12" r="7" fill="#EB001B"/>
                  <circle cx="23" cy="12" r="7" fill="#F79E1B"/>
                  <path d="M19 6.8A7 7 0 0 1 22.2 12 7 7 0 0 1 19 17.2 7 7 0 0 1 15.8 12 7 7 0 0 1 19 6.8z" fill="#FF5F00"/>
                </svg>
              </div>
              {/* مدى */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center" style={{ background: '#007A3D' }}>
                <span className="text-white font-black text-xs tracking-wide">مدى</span>
              </div>
              {/* Apple Pay */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center" style={{ background: '#000' }}>
                <svg viewBox="0 0 165 105" height="16" fill="white" xmlns="http://www.w3.org/2000/svg">
                  <path d="M30 21c-3-4-8-6-13-6C10 15 3 22 3 30c0 5 2 9 6 12 3 3 7 5 12 5 5 0 10-2 13-6l-4-4c-2 3-5 4-9 4-3 0-6-1-8-3-2-2-3-5-3-8 0-3 1-6 3-8 2-2 5-3 8-3 3 0 6 1 8 4l4-2zM53 44V15h-6v29h6zM76 18c-2-2-5-3-9-3-4 0-7 1-9 3l3 4c2-1 4-2 6-2 2 0 4 0 5 1 1 1 2 3 2 5v2c-2-1-4-2-7-2-3 0-6 1-8 3-2 2-3 4-3 7s1 5 3 7c2 2 5 3 8 3 3 0 6-1 8-3v3h5V26c0-4-1-6-4-8zm-3 18c-1 2-3 2-5 2-2 0-4-1-5-2-1-1-2-2-2-4s1-3 2-4c1-1 3-2 5-2 2 0 4 1 5 2v8zM107 44l-12-29h-7l-12 29h7l3-7h12l3 7h6zm-18-12l4-11 4 11h-8zM140 15h-7l-8 11-8-11h-7l12 16v13h6V31l12-16z"/>
                </svg>
              </div>
              {/* Tabby */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center" style={{ background: '#3DBEB0' }}>
                <span className="text-white font-black text-xs">tabby</span>
              </div>
              {/* Tamara */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center" style={{ background: '#D4F0A3' }}>
                <span className="font-black text-xs" style={{ color: '#1a1a1a' }}>tamara</span>
              </div>
              {/* COD */}
              <div className="h-8 px-3 rounded-lg flex items-center justify-center gap-1.5" style={{ background: 'rgba(255,255,255,0.1)' }}>
                <span className="text-base">💵</span>
                <span className="text-xs font-bold text-gray-300">الدفع عند الاستلام</span>
              </div>
            </div>
            <p className="text-xs text-gray-500">الرقم الضريبي: 310123456700003</p>
            <p className="text-xs text-gray-500 mt-1">سجل تجاري: 1010XXXXXX</p>
          </div>
        </div>
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-gray-500"
          style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <p>© {new Date().getFullYear()} twsaa.com — جميع الحقوق محفوظة</p>
          <p>مرخص من وزارة التجارة • المملكة العربية السعودية</p>
        </div>
      </div>
    </footer>
  )
}

// ─── Category Page ───────────────────────────────────────────────────────────

const SORT_OPTIONS = [
  { value: 'name-asc',    label: 'الاسم: أ - ي' },
  { value: 'name-desc',   label: 'الاسم: ي - أ' },
  { value: 'price-asc',  label: 'السعر: الأقل أولاً' },
  { value: 'price-desc', label: 'السعر: الأعلى أولاً' },
  { value: 'rating-desc',label: 'الأعلى تقييماً' },
  { value: 'newest',     label: 'الأحدث' },
]

const PRICE_RANGES = [
  { label: 'الكل', min: 0, max: Infinity },
  { label: 'أقل من 500 ر.س', min: 0, max: 500 },
  { label: '500 - 1,500 ر.س', min: 500, max: 1500 },
  { label: '1,500 - 5,000 ر.س', min: 1500, max: 5000 },
  { label: 'أكثر من 5,000 ر.س', min: 5000, max: Infinity },
]

function CategoryPage({ category, onProductSelect, onAddCart }: {
  category: { name: string; icon: string }
  onProductSelect: (p: Product) => void
  onAddCart: (p: Product) => void
}) {
  const [sort, setSort] = useState('newest')
  const [priceRange, setPriceRange] = useState(0)
  const [onlyInStock, setOnlyInStock] = useState(false)
  const [onlyNew, setOnlyNew] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [allLoaded, setAllLoaded] = useState(false)
  const [visibleProducts, setVisibleProducts] = useState<Product[]>([])
  const sentinelRef = useRef<HTMLDivElement>(null)
  const actionRef = useRef<'active' | 'inactive'>('inactive')

  // Filter + sort the full pool
  const filtered = ALL_PRODUCTS_POOL
    .filter(p => {
      const range = PRICE_RANGES[priceRange]
      if (p.rawPrice < range.min || p.rawPrice > range.max) return false
      if (onlyInStock && !p.saleable) return false
      if (onlyNew && !p.isNew) return false
      return true
    })
    .sort((a, b) => {
      if (sort === 'price-asc')  return a.rawPrice - b.rawPrice
      if (sort === 'price-desc') return b.rawPrice - a.rawPrice
      if (sort === 'rating-desc') return b.rating - a.rating
      if (sort === 'newest')     return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0)
      if (sort === 'name-asc')   return a.name.localeCompare(b.name, 'ar')
      if (sort === 'name-desc')  return b.name.localeCompare(a.name, 'ar')
      return 0
    })

  // Reset on filter/sort change
  useEffect(() => {
    setPage(1)
    setAllLoaded(false)
    setVisibleProducts(filtered.slice(0, PAGE_SIZE))
    if (filtered.length <= PAGE_SIZE) setAllLoaded(true)
  }, [sort, priceRange, onlyInStock, onlyNew])

  // Simulate AJAX load-more
  const loadMore = useCallback(() => {
    if (actionRef.current === 'active' || allLoaded) return
    actionRef.current = 'active'
    setLoading(true)
    setTimeout(() => {
      const nextPage = page + 1
      const nextSlice = filtered.slice(0, nextPage * PAGE_SIZE)
      setVisibleProducts(nextSlice)
      setPage(nextPage)
      if (nextSlice.length >= filtered.length) setAllLoaded(true)
      setLoading(false)
      actionRef.current = 'inactive'
    }, 600)
  }, [page, allLoaded, filtered])

  // IntersectionObserver on sentinel — mirrors the scroll handler in category/index.twig
  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) loadMore()
    }, { threshold: 0.1 })
    obs.observe(el)
    return () => obs.disconnect()
  }, [loadMore])

  const filterCount = [priceRange > 0, onlyInStock, onlyNew].filter(Boolean).length

  return (
    <div className="max-w-7xl mx-auto px-4 py-8" style={{ direction: 'rtl' }}>
      {/* Hero image strip — mirrors category.image_url block */}
      <div className="relative rounded-2xl overflow-hidden mb-8" style={{ height: 180 }}>
        <img
          src="https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=1200&h=360&fit=crop&auto=format"
          alt={category.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 flex items-center px-10"
          style={{ background: 'linear-gradient(to left, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.25) 60%, transparent 100%)' }}>
          <div>
            <p className="text-sm font-semibold text-blue-200 mb-1">{category.icon} فئة</p>
            <h1 className="text-3xl font-black text-white section-title">{category.name}</h1>
            <p className="text-sm text-gray-300 mt-1">{filtered.length} منتج متاح</p>
          </div>
        </div>
      </div>

      <div className="flex gap-6 items-start">
        {/* ── Sidebar filters ── */}
        <aside className="w-56 flex-shrink-0 space-y-4">
          {/* Active filter chips */}
          {filterCount > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {priceRange > 0 && (
                <button onClick={() => setPriceRange(0)}
                  className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-semibold"
                  style={{ background: 'var(--brand-light,#eef2ff)', color: 'var(--brand)' }}>
                  {PRICE_RANGES[priceRange].label} ✕
                </button>
              )}
              {onlyInStock && (
                <button onClick={() => setOnlyInStock(false)}
                  className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-semibold"
                  style={{ background: '#dcfce7', color: '#16a34a' }}>
                  متوفر فقط ✕
                </button>
              )}
              {onlyNew && (
                <button onClick={() => setOnlyNew(false)}
                  className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-semibold"
                  style={{ background: '#fef9c3', color: '#a16207' }}>
                  جديد فقط ✕
                </button>
              )}
            </div>
          )}

          {/* Price range */}
          <div className="bg-white rounded-2xl p-4" style={{ border: '1.5px solid var(--border)' }}>
            <h3 className="font-bold text-sm mb-3 section-title">نطاق السعر</h3>
            <ul className="space-y-1">
              {PRICE_RANGES.map((r, i) => (
                <li key={i}>
                  <button onClick={() => setPriceRange(i)}
                    className="w-full text-right flex items-center gap-2.5 py-1.5 px-2 rounded-lg text-sm transition-colors"
                    style={{
                      background: priceRange === i ? 'var(--brand-light,#eef2ff)' : 'transparent',
                      color: priceRange === i ? 'var(--brand)' : 'var(--foreground)',
                      fontWeight: priceRange === i ? 700 : 400,
                    }}>
                    <span className="w-3.5 h-3.5 rounded-full border-2 flex-shrink-0 flex items-center justify-center"
                      style={{ borderColor: priceRange === i ? 'var(--brand)' : 'var(--border)' }}>
                      {priceRange === i && <span className="w-2 h-2 rounded-full" style={{ background: 'var(--brand)' }} />}
                    </span>
                    {r.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Availability */}
          <div className="bg-white rounded-2xl p-4" style={{ border: '1.5px solid var(--border)' }}>
            <h3 className="font-bold text-sm mb-3 section-title">التوفر</h3>
            <label className="flex items-center gap-2.5 cursor-pointer py-1">
              <input type="checkbox" checked={onlyInStock} onChange={e => setOnlyInStock(e.target.checked)}
                className="w-4 h-4 rounded" style={{ accentColor: 'var(--brand)' }} />
              <span className="text-sm">متوفر في المخزون فقط</span>
            </label>
            <label className="flex items-center gap-2.5 cursor-pointer py-1">
              <input type="checkbox" checked={onlyNew} onChange={e => setOnlyNew(e.target.checked)}
                className="w-4 h-4 rounded" style={{ accentColor: 'var(--brand)' }} />
              <span className="text-sm">منتجات جديدة فقط</span>
            </label>
          </div>

          {/* Sub-categories */}
          <div className="bg-white rounded-2xl p-4" style={{ border: '1.5px solid var(--border)' }}>
            <h3 className="font-bold text-sm mb-3 section-title">الفئات الفرعية</h3>
            <ul className="space-y-1">
              {['الهواتف الذكية','اللابتوب','الصوتيات','الكاميرات','الشاشات','الملحقات'].map(sub => (
                <li key={sub}>
                  <button className="w-full text-right py-1.5 px-2 rounded-lg text-sm hover:bg-gray-50 transition-colors flex items-center justify-between">
                    <span>{sub}</span>
                    <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                      {Math.floor(Math.random() * 20) + 2}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* ── Main product grid ── */}
        <div className="flex-1 min-w-0">
          {/* Toolbar: sort + count + view toggle */}
          <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
            <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
              عرض <strong style={{ color: 'var(--foreground)' }}>{visibleProducts.length}</strong> من {filtered.length} منتج
            </p>
            <div className="flex items-center gap-2">
              {/* View mode */}
              <div className="flex rounded-xl overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
                <button onClick={() => setViewMode('grid')}
                  className="w-9 h-9 flex items-center justify-center text-sm transition-colors"
                  style={{ background: viewMode === 'grid' ? 'var(--brand)' : '#fff', color: viewMode === 'grid' ? '#fff' : 'var(--muted-foreground)' }}>
                  ⊞
                </button>
                <button onClick={() => setViewMode('list')}
                  className="w-9 h-9 flex items-center justify-center text-sm transition-colors"
                  style={{ background: viewMode === 'list' ? 'var(--brand)' : '#fff', color: viewMode === 'list' ? '#fff' : 'var(--muted-foreground)' }}>
                  ☰
                </button>
              </div>
              {/* Sort select */}
              <select value={sort} onChange={e => setSort(e.target.value)}
                className="text-sm px-3 py-2 rounded-xl outline-none"
                style={{ border: '1.5px solid var(--border)', background: '#fff', color: 'var(--foreground)' }}>
                {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>

          {/* Products */}
          {visibleProducts.length === 0 ? (
            <div className="text-center py-24 space-y-3">
              <div className="text-6xl">🔍</div>
              <p className="font-bold text-lg">لا توجد منتجات تطابق الفلاتر المحددة</p>
              <button onClick={() => { setPriceRange(0); setOnlyInStock(false); setOnlyNew(false) }}
                className="px-5 py-2.5 rounded-xl font-bold text-sm text-white"
                style={{ background: 'var(--brand)' }}>
                إعادة ضبط الفلاتر
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {visibleProducts.map(p => (
                <ProductCard key={p.id} product={p} onSelect={() => onProductSelect(p)} onAddCart={onAddCart} />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {visibleProducts.map(p => (
                <div key={p.id} className="bg-white rounded-2xl flex gap-4 p-4 cursor-pointer hover:shadow-md transition-all"
                  style={{ border: '1.5px solid var(--border)' }}
                  onClick={() => onProductSelect(p)}>
                  <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0" style={{ background: '#f0f4ff' }}>
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold text-sm leading-snug mb-1">{p.name}</p>
                        <div className="flex items-center gap-1 mb-2">
                          <Stars rating={p.rating} />
                          <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>({p.reviews})</span>
                        </div>
                      </div>
                      <div className="text-left flex-shrink-0">
                        <p className="font-black text-base" style={{ color: 'var(--brand)' }}>{p.price}</p>
                        {p.oldPrice && <p className="text-xs line-through" style={{ color: 'var(--muted-foreground)' }}>{p.oldPrice}</p>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {p.promo && <span className="text-xs px-2 py-0.5 rounded-full font-bold text-white" style={{ background: 'var(--accent)' }}>{p.promo}</span>}
                      <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                        style={{ background: p.saleable ? '#dcfce7' : '#fee2e2', color: p.saleable ? '#16a34a' : '#e8412a' }}>
                        {p.saleable ? 'متوفر' : 'نفذ'}
                      </span>
                      <button onClick={e => { e.stopPropagation(); onAddCart(p) }}
                        className="mr-auto px-3 py-1 rounded-lg text-xs font-bold text-white disabled:opacity-40"
                        style={{ background: 'var(--brand)' }}
                        disabled={!p.saleable}>
                        + سلة
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Sentinel for infinite scroll — mirrors $(window).scroll in category/index.twig */}
          <div ref={sentinelRef} className="flex items-center justify-center py-8">
            {loading && (
              <div className="flex items-center gap-3" style={{ color: 'var(--muted-foreground)' }}>
                <div className="w-5 h-5 rounded-full border-2 border-t-transparent animate-spin"
                  style={{ borderColor: 'var(--brand)', borderTopColor: 'transparent' }} />
                <span className="text-sm">جاري التحميل...</span>
              </div>
            )}
            {allLoaded && visibleProducts.length > 0 && (
              <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                ✓ تم عرض جميع المنتجات ({filtered.length})
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0])
  const [cartItems, setCartItems] = useState<Product[]>([])
  const [cartOpen, setCartOpen] = useState(false)

  const addToCart = (p: Product) => setCartItems(prev => [...prev, p])
  const removeFromCart = (idx: number) => setCartItems(prev => prev.filter((_, i) => i !== idx))

  const handleProductSelect = (p: Product) => {
    setSelectedProduct(p)
    setPage('product')
    window.scrollTo(0, 0)
  }

  const handleCategorySelect = (cat: typeof CATEGORIES[0]) => {
    setSelectedCategory(cat)
    setPage('category')
    window.scrollTo(0, 0)
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--background)', direction: 'rtl' }}>
      <Header
        cartCount={cartItems.length}
        onCartClick={() => setCartOpen(true)}
        onPageChange={p => { setPage(p); setSelectedProduct(null); window.scrollTo(0,0) }}
        onCategorySelect={handleCategorySelect}
        activePage={page}
      />

      {cartOpen && <CartDrawer items={cartItems} onClose={() => setCartOpen(false)} onRemove={removeFromCart} />}

      {page === 'home' && (
        <HomePage
          onProductSelect={handleProductSelect}
          onAddCart={addToCart}
          onCategorySelect={handleCategorySelect}
        />
      )}

      {page === 'category' && (
        <CategoryPage
          category={selectedCategory}
          onProductSelect={handleProductSelect}
          onAddCart={addToCart}
        />
      )}

      {page === 'product' && selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          onBack={() => { setPage('home'); window.scrollTo(0,0) }}
          onAddCart={addToCart}
        />
      )}

      {page === 'account' && <AccountPage />}

      <Footer />
    </div>
  )
}
