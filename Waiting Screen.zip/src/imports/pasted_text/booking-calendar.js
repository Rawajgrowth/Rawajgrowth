<div class="booking__details">
    <div class="row">
        <div class="col-md-8">
            <div id="calendar"></div>
            <div class="booking__reserved mt-4">
                <label class="d-block mb-2">
                    {{ ('admin::app.catalog.products.remaining_sessions'|trans) }} 
                </label>
                <ul class="list" id="selected-slots">
                </ul>
            </div>
        </div>
        <div class="col-md-4">
            <div id="slots"></div>
        </div>
    </div>
    <input type="hidden" id="booking" name="booking">
</div>
<link href="{{ asset_url ~( 'themes/default/assets/css/calendar.css') }}"  media="all" rel="stylesheet" type="text/css">

{% block footer_scripts %}
<script type="text/javascript" src="{{ "https://twsaa.com/admin-themes/mbotiq/assets/js/plugins/full-calendar/main.min.js" }}"></script>
<script type="text/javascript" src="{{ "https://twsaa.com/admin-themes/mbotiq/assets/js/plugins/full-calendar/locales-all.min.js" }}"></script>

<script>
$(document).ready(function() {
    var activeDays = {
        startTime: '12:00',
        endTime: '23:00',
        daysOfWeek: {{ product['slot_days'] }}
    },
    booking_overrides = [],
    reservations = [],
    current_date = null,
    max_slots = {{ product['booking']['max_qty'] }},
    booking_type = "{{ product['product_booking_type'] }}",
    excludedDatesList = [];
    var calendarEl = document.getElementById('calendar'),
        calendar = new FullCalendar.Calendar(calendarEl, {
            headerToolbar: {
                start: '',
                center: 'title',
                end: 'prev,next'
            },
            initialView: 'dayGridMonth',
            locale: '{{ getFunction('locale') }}',
            contentHeight: 500,
            //   schedulerLicenseKey: '0893078531-fcs-1629792461',
            unselectAuto: true,
            dateClick: function(info) {
                const day = info.date.getDay(),
                findDay = activeDays.daysOfWeek.findIndex(item => item === day);
                current_date = info;
            if (findDay === -1) {


                if(booking_type == 'many')
                {
                    dateSelected(info.dateStr);
                }else{
                    daySelected(info.dateStr);
                }

                var dateIndex = booking_overrides.findIndex(item => {
                    return item.date === info.dateStr;
                });

                if (dateIndex !== -1) {
                    booking_overrides.splice(dateIndex, 1);
                    excludedDatesList.splice(dateIndex, 1);
                }
                booking_overrides.push({
                    day: day,
                    date: info.dateStr
                });

                excludedDatesList.push(`${info.dateStr}`);
            }
            else{
                $('#slots').html('');
            }
        },
        validRange (nowDate) {
            return {
                start: nowDate
            }
        },
    });

    function addSelectedDate() {
        if(reservations.length > 0)
        {
            $.each(reservations, function(key, value) {
                $.each(value, function(subKey, subValue) {
                    var element = $('.fc-daygrid-day.fc-day[data-date="'+subValue+'"]');
                    if (element.length) {
                        element.addClass('selected');
                    }
                });
            });
        }
    }
    function removeSelectedDate(date) {
        $.each(reservations, function(key, value) {
            $.each(value, function(subKey, subValue) {
                if(date == subValue)
                {        
                    var element = $('.fc-daygrid-day.fc-day[data-date="'+subValue+'"]');
                    if (element.length) {
                        element.removeClass('selected');
                    }
                }
            });
        });
    }
    function daySelected(date) {
        if(max_slots == reservations.length)
        {
            $('#fc-media-screen').addClass('disabled');
            return;
        }

        let dateEntry = reservations.find(entry => entry.date === current_date.dateStr);
        if (dateEntry) {
                return;
        }

        var html = '<li class="child-slot"><div><span class=""><i class="icon-calendar"></i>'
        html += current_date.dateStr
        html += '</span></div> <button type="button" class="btn remove-slot" data-date="'
        html += current_date.dateStr
        html += '"><i class="icon-trash-2"></i></button></li>'
        $("#selected-slots").append(html);

        reservations.push({
            day: current_date.date.getDay(),
            date: current_date.dateStr,
            time: [{
                from: "",
                to: ''
            }]
        });

        addSelectedDate();
        $("#booking").val(JSON.stringify(reservations))
    }

    function dateSelected(date) {
        $.ajax({
            url: "{{ route('booking_product.slots.get', bookingProduct['id']) }}",
            type: "GET",
            data: { date: date },
            success: function(response) {
                $('#slots').html(response.data)
            },
            error: function(error) {
                console.error("Error fetching slots:", error);
            }
        });
    }
    function formatTimestamp(timestamp) {
        let date = new Date(timestamp * 1000); // Convert to milliseconds
        return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    }
    $(document.body).on('click',".select-slot",function (e) {
        if(max_slots == reservations.length)
        {
            $('#slots').html('');
            return;
        }

        var timestamp =  $(this).data('timestamp'); 
        let parts = timestamp.split("-");
        let start = formatTimestamp(parts[0]);
        let end = formatTimestamp(parts[1]);

        let dateEntry = reservations.find(entry => entry.date === current_date.dateStr);
        if (dateEntry) {
            let timeExists = dateEntry.time.some(slot => slot.from === start && slot.to === end);
            if (timeExists) {
                return;
            }
        }
        console.log(current_date)
        var html = '<li class="child-slot"><div><span class="has-time"><i class="icon-calendar"></i>'
        html += current_date.dateStr
        html += '</span> <span class="time"><i class="icon-time"></i>'
        html += start+' - '+end
        html += '</span></div> <button type="button" class="btn remove-slot" data-date="'
        html += current_date.dateStr
        html += '"><i class="icon-trash-2"></i></button></li>'
        $("#selected-slots").append(html);

        reservations.push({
            day: current_date.date.getDay(),
            date: current_date.dateStr,
            time: [{
                from: start,
                to: end
            }]
        });

        addSelectedDate();
        $("#booking").val(JSON.stringify(reservations))
        if(max_slots == reservations.length)
        {
            $('#slots').html('');
            return;
        }
    });

    $(document.body).on('click',".remove-slot",function (e) {
        let date = $(this).data('date'); 
        let childIndex = $(this).closest('.child-slot').index();
        removeSelectedDate(date);
        reservations.splice(childIndex,1);
        $(this).closest('.child-slot').remove();
        addSelectedDate();
        $("#booking").val(JSON.stringify(reservations));
        $('#fc-media-screen').removeClass('disabled');

    });

    $(function() {
        $('#calendar').slideDown();
        $(this).hide().siblings('.btn').show()
        calendar.render();
        $('.fc-next-button, .fc-prev-button').on('click', function () {
            booking_overrides.forEach(item => {
                $(`td[data-date=${item.date}]`).addClass('selected')
            });
        });
        if (booking_overrides.length > 0) {
            booking_overrides.forEach(item => {
                $(`td[data-date="${item.date}"]`).addClass('selected');
            });
        }
    });
      
    // $('.click2').click(function () {
    //     console.log('asdf2');
    //     $('#calendar').slideUp();
    //     if (booking_overrides.length) {
    //     $(this).hide().siblings('.btn').html(`<i class="icon-pencil font-14 mr-5"></i> تعديل`).show();
    //     excludedDatesList.forEach((e, index, array) => {
    //         let dateList = `
    //                     <li class="mb-10">
    //                         <span data-excluded-date="${e}" class="font-13 d-block pr-10 mr-10">
    //                             ${e}
    //                             <button class="btn btn-delete btn-delete-circle btn-delete--small btn-delete--light v-align ml-5">
    //                                 <i class="icon-cancel"></i>
    //                             </button>
    //                         </span>
    //                     </li>
    //                 `;
    //         $('.excluded-dates #excluded_dates ul').append(dateList);
    //         excludedDatesList = [];
    //     });
    //     $('#excluded_dates .btn-delete-circle').on('click', function () {
    //         deleteExcludedDate($(this))
    //     });
    //     $('.excluded-dates #excluded_dates').show();
    //     } else {
    //     $(this).hide().siblings('.btn').html(`<i class="icon-add mr-5 font-14"></i> اضافة`).show();
    //     }
    // });
});

</script>
{% endblock %}